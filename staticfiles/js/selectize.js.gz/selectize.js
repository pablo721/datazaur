

$(document).ready(function () {
    let lol = $('#id_coin');
    console.log(lol);
    lol.selectize({
      sortField: 'text'
        });
    });

